package Modelo;

public class Cuenta {
    private int noCuenta;
    private String tipoCuenta;
    private double saldoInical;
    private double saldo;

    public Cuenta(int noCuenta, String tipoCuenta, double saldoInical, double saldo) {
        this.noCuenta = noCuenta;
        this.tipoCuenta = tipoCuenta;
        this.saldoInical = saldoInical;
        this.saldo = saldo;
    }

    /**
     * @return the noCuenta
     */
    public int getNoCuenta() {
        return noCuenta;
    }

    /**
     * @param noCuenta the noCuenta to set
     */
    public void setNoCuenta(int noCuenta) {
        this.noCuenta = noCuenta;
    }

    /**
     * @return the tipoCuenta
     */
    public String getTipoCuenta() {
        return tipoCuenta;
    }

    /**
     * @param tipoCuenta the tipoCuenta to set
     */
    public void setTipoCuenta(String tipoCuenta) {
        this.tipoCuenta = tipoCuenta;
    }

    /**
     * @return the saldoInical
     */
    public double getSaldoInical() {
        return saldoInical;
    }

    /**
     * @param saldoInical the saldoInical to set
     */
    public void setSaldoInical(double saldoInical) {
        this.saldoInical = saldoInical;
    }

    /**
     * @return the saldo
     */
    public double getSaldo() {
        return saldo;
    }

    /**
     * @param saldo the saldo to set
     */
    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
    
    
}

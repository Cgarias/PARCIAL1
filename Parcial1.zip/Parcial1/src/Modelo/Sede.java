package Modelo;

public class Sede {
    private String nombre;
    private String direccion;
    private String ciudad;
    private int noMaxCuentas;
    private int codigo;
    
    private Cuenta cuentas[];
    private int noCuentasCreadas;

    public Sede(String nombre, String direccion, String ciudad, int noMaxCuentas, int codigo) {
        this.nombre = nombre;
        this.direccion = direccion;
        this.ciudad = ciudad;
        this.noMaxCuentas = noMaxCuentas;
        this.codigo = codigo;
        this.cuentas= new Cuenta[noMaxCuentas];
        this.noCuentasCreadas=0;
    }

    Sede(int noMaxSedes) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public int getNoMaxCuentas() {
        return noMaxCuentas;
    }

    public void setNoMaxCuentas(int noMaxCuentas) {
        this.noMaxCuentas = noMaxCuentas;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public Cuenta[] getCuenta() {
        return cuentas;
    }

    public void setCuenta(Cuenta[] cuentas) {
        this.cuentas = cuentas;
    }
    
    public boolean crearNewCuenta(int noCuenta, String tipoCuenta, double saldoInical, double saldo){
        if(this.noCuentasCreadas<this.noMaxCuentas){
            Cuenta g = new Cuenta(noCuenta, tipoCuenta, saldoInical, saldo);
            this.cuentas[this.noCuentasCreadas]=g;
            this.noCuentasCreadas++;
            return true;
        }
        return false;
    }
    
    
}



package Modelo;

public class Banco {
    private String nombre;
    private int noMaxSedes;
    
    private Sede sedes[];
    private int noSedesCreadas;

    public Banco(String nombre, int noMaxSedes) {
        this.nombre = nombre;
        this.noMaxSedes = noMaxSedes;
        this.sedes = new Sede[noMaxSedes];
        this.noSedesCreadas = 0;        
    }

    public Banco(String nombre) {
        this.nombre = nombre;
    }

    public Banco(int noMaxSedes) {
        this.noMaxSedes = noMaxSedes;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getNoMaxSedes() {
        return noMaxSedes;
    }

    public void setNoMaxSedes(int noMaxSedes) {
        this.noMaxSedes = noMaxSedes;
    }
    
    public boolean crearNewSede(String nombre, String direccion, String ciudad, int noMaxCuentas, int codigo){
        if(this.noSedesCreadas<noMaxSedes){
            Sede g = new Sede(nombre, direccion, ciudad, noMaxCuentas, codigo);
            this.sedes[this.noSedesCreadas]=g;
            this.noSedesCreadas++;
            return true;
        }
        return false;
    }
    
    
}

